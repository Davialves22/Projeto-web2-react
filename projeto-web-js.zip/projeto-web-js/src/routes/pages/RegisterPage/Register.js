import { Link } from 'react-router-dom';

export function Resgister() {

    return (
        <div className={'container'}>
            <main className={'centralize'}>

                <section className={'section'}>
                    <div className={'text'}>
                        <h3>CADASTRE-SE</h3>
                    </div>
                </section>

                <section className={'section'}>
                    <form className={'form'}>
                        <section className={'inputNome'}>
                            <span className={`bi bi-person-fill ${'customIcons'}`}></span>
                            <input type="email" placeholder="Digite o seu Nome Completo" />
                        </section>

                        <section className={'inputCpf'}>
                            <span className={`bi bi-key-fill ${'customIcon'}`}></span>
                            <input type="text" placeholder="Digite seu CPF" required />
                        </section>

                        <section className={'inputBirth'}>
                            <span className={`bi bi-key-fill ${'customIcon'}`}></span>
                            <input type="date" />
                        </section>

                        <section className={'inputGender'}>
                            <input type="radio" name="genderMas" />Masculino
                            <input type="radio" name="genderFem" />Feminino
                        </section>

                        <section className={'inputEmail'}>
                            <input type="text" placeholder="exemple@exemple.com" />
                        </section>

                        <section className={'inputCellphone'}>
                            <input type="tel" id="phone" name="phone" pattern="[0-9]{3}-[0-9]{2}-[0-9]{3}" />
                        </section>

                        <section className={'inputPassword'}>
                            <span className={`bi bi-key-fill ${'customIcon'}`}></span>
                            <input type="password" placeholder="Senha" />
                        </section>

                        <section className={'inputPassword'}>
                            <span className={`bi bi-key-fill ${'customIcon'}`}></span>
                            <input type="password" placeholder="Confirme sua senha" />
                        </section>

                        <Link to="/" ><button className={'enter'} >ENTRAR</button></Link>

                    </form>
                </section>

            </main>
        </div>
    );
}
