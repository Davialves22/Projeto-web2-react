import { render, screen } from "@testing-library/react";
import { Login } from "./Login";
import userEvent from "@testing-library/user-event";
import '@testing-library/jest-dom';

describe("Login", () => {
    test("dado o email, quando estiver vazio, então exibe a mensagem de erro obrigatória", async () => {
        render(<Login />);

        const email = screen.getByTestId("email");

        await userEvent.type(email, "anyValue");
        await userEvent.clear(email);

        const requiredError = screen.queryByTestId("email-required");
        expect(requiredError).not.toBeNull();
    });

    test("dado o email, quando tiver valor, então esconde a mensagem de erro obrigatória", async () => {
        render(<Login />);

        const email = screen.getByTestId("email");

        await userEvent.type(email, "anyValue");

        const requiredError = screen.queryByTestId("email-required");
        expect(requiredError).toBeNull();
    });

    test("dado o email, quando o campo não tiver mudado, então esconde a mensagem de erro obrigatória", async () => {
        render(<Login />);

        const requiredError = screen.queryByTestId("email-required");
        expect(requiredError).toBeNull();
    });

    test("dado o email, quando for inválido, então exibe a mensagem de erro de email inválido", async () => {
        render(<Login />);

        const email = screen.getByTestId("email");

        await userEvent.type(email, "anyValue");

        const requiredError = screen.queryByTestId("email-invalid");
        expect(requiredError).not.toBeNull();
    });

    test("dada a senha, quando estiver vazia, então exibe a mensagem de erro obrigatória", async () => {
        render(<Login />);

        const password = screen.getByTestId("password");

        await userEvent.type(password, "anyValue");
        await userEvent.clear(password);

        const requiredError = screen.queryByTestId("password-required");
        expect(requiredError).not.toBeNull();
    });

    test("dada a senha, quando tiver valor, então esconde a mensagem de erro obrigatória", async () => {
        render(<Login />);

        const password = screen.getByTestId("password");

        await userEvent.type(password, "anyValue");

        const requiredError = screen.queryByTestId("password-required");
        expect(requiredError).toBeNull();
    });

    test("dado o email, quando estiver vazio, então desativa o botão de recuperar senha", () => {
        render(<Login />);

        const recoverPasswordButton = screen.getByTestId('recover-password-button');

        expect(recoverPasswordButton).toBeDisabled();
    });

    test("dado o email, quando for válido, então ativa o botão de recuperar senha", () => {
        render(<Login />);

        const email = screen.getByTestId('email');
        userEvent.type(email, "valid@email.com");

        const recoverPasswordButton = screen.getByTestId('recover-password-button');

        expect(recoverPasswordButton).not.toBeDisabled();
    });

    test("dado o formulário inválido, então desativa o botão de login", () => {
        render(<Login />);

        const loginButton = screen.getByTestId('login-button');

        expect(loginButton).toBeDisabled();
    });

    test("dado o formulário válido, então ativa o botão de login", () => {
        render(<Login />);

        const email = screen.getByTestId('email');
        userEvent.type(email, "valid@email.com");
        const password = screen.getByTestId("password");
        userEvent.type(password, "anyValue");

        const loginButton = screen.getByTestId('login-button');

        expect(loginButton).not.toBeDisabled();
    });
});
