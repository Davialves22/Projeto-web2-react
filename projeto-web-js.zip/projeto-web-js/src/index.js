import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { App } from './App';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import "bootstrap/dist/css/bootstrap.min.css";
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Home } from "./routes/pages/homePage/Home";
import { Login } from "./routes/pages/loginPage/Login";
import { Resgister } from "./routes/pages/RegisterPage/Register";
//import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Produto } from './routes/pages/produtosPage/Produtos'
import { ProductDescription } from './components/productDescription/ProductDescription';


const router = createBrowserRouter([
  {
    path: '/', element: <App />, children: [
      { path: '/', element: <Home /> },
      { path: '/Login', element: <Login /> },
      { path: '/Produto', element: <Produto /> },
      { path: '/Register', element: <Resgister /> },
      { path: '/Descricao', element: <ProductDescription /> },
      { path: '*', element: <h1>Page Not Found</h1> },  // 404 Page  // Default Route

    ]
  }
])


const root = ReactDOM.createRoot(
  document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);