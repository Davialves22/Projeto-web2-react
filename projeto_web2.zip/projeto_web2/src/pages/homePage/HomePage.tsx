import styles from "./Home.module.css";
import { CarouselCards1 } from "../../components/carroussel/CarrousselCards1";
import { CarouselSlides } from './../../components/carroussel/carrousseSlides'

export function HomePage() {
  return (
    <>
      <h1>HomePage</h1>
      <CarouselSlides />

      <section className="container">
        <div className={styles.container}>
          <CarouselCards1 />
        </div>

        <ul>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>


      </section>
    </>
  );
}
