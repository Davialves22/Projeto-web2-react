import { LoginPage } from "./pages/loginPage/LoginPage";
import { Header } from "./components/Header/Header"
import { Footer } from "./components/Footer/Footer";
import { HomePage } from "./pages/homePage/HomePage";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Register from "./pages/Register/Register";

export function App() {
  return (
    <div>
      <Header />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage/>}/>
          <Route path="/register" element = {<Register/>}/>
          <Route path="/home" element = {<HomePage/>}/>
        </Routes>
      </BrowserRouter><br/><br /><br /><br /><br />
      <Footer />
    </div>
  );
}
