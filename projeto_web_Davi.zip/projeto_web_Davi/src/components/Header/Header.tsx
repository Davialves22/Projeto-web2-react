import React from 'react';
import { HeaderProps } from './../../interfaces/Header.types'
import { Link, useLocation } from 'react-router-dom';
import classes from './Header.module.css';
import logo from './../../assets/images/Logo_png.png';



export const Header: React.FC<HeaderProps> = ({ username }) => {
  const location = useLocation();
  const isLoginPage = location.pathname === '/LoginPage';

  return (
    <header className={classes.header}>
      <nav className="navbar navbar-expand-lg navbar-light">
        <div className="container-fluid">

          <a className="navbar-brand"
            href="/">
            <img src={logo}
              alt="Logo"
              width="140"
              height="130" />
          </a>


          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarNav">

            {!isLoginPage && (
              <div className={`${classes.inputGroup} ms-auto me-auto`}>
                <input
                  className={`${classes.formControl}`}
                  type="search"
                  placeholder="Buscar..."
                  aria-label="Search"
                />

                <button className={classes.btn} type="submit">
                  <i className="bi bi-search" />
                </button>
              </div>
            )}

            <div className={classes.btnLogin}>
              <form className="d-flex ms-auto" role="search">
                <Link to="/LoginPage" className="btn">
                  <button className={classes.buttonL}>
                    <div className={classes.buttonContent}>
                      <span className="bi bi-person-fill" />
                      <div className={classes.textContent}>
                        <p>{username || 'NOME DE USUÁRIO'}</p>
                        <div className={classes.links}>
                          <Link to='/'>minha conta</Link>
                          <div>|</div>
                          <Link to='/'>sair</Link>
                        </div>
                      </div>
                    </div>
                  </button>
                </Link>
              </form>
            </div>



          </div>
        </div>
      </nav>
    </header>
  );
};
