export interface CardData {
    id: string; 
    title: string;
    text: string;
    imageSrc: string;
    price: number;
}