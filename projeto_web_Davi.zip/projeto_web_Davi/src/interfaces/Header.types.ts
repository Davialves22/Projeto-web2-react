export interface HeaderProps {
    username?: string; //para que o nome de usuario seja opcional
}