import './App.css';
import CadastroProdutos from './components/CadastroProdutos';

function App() {
  return (
    <>
    <CadastroProdutos/>
    </>
  );
}

export default App;
