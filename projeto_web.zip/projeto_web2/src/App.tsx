//import { LoginPage } from "./pages/loginPage/LoginPage";
import { Header } from "./components/Header/Header"
import { Footer } from "./components/Footer/Footer";
//import { HomePage } from "./pages/homePage/HomePage";
//import { BrowserRouter, Route, Routes } from "react-router-dom";
//import  Register from "./pages/Register/Register";
import { Outlet } from "react-router-dom";


export function App() {
  return (
    <div className="App">
      <Header />
      <Outlet />
      <Footer />
    </div>
  );
}


/*export function App() {
  return (
    <div>
      <Header />
      <BrowserRouter>
        <Routes>
         <Route path="/" element = {<HomePage/>}/>
          <Route path="/LoginPage" element={<LoginPage/>}/>
          <Route path="/register" element = {<Register/>}/>
          
        </Routes>
      </BrowserRouter><br/><br /><br /><br /><br />
      <Footer />
    </div>
  );
}*/
