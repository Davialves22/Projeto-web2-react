import React from 'react';
import {CardProps} from './../../interfaces/CardProps'
import styles from './Card.module.css';


export const Card: React.FC<CardProps> = ({
    title,
    text,
    imageSrc,
    buyButtonText,
    buyButtonLink,
    cartButtonText,
    cartButtonLink
}) => (
    <div className={`card ${styles.Card}`}>
        <img src={imageSrc} className="card-img-top" alt={title} />
        <div className={`card-body${styles.Body}`}>
            <h5 className="card-title">{title}</h5>
            <p className="card-text">{text}</p>
            <div className={styles.buttonGroup}>
                <a href={buyButtonLink} className={`btn btn-primary ${styles.buyButton}`}>{buyButtonText}</a>
                <a href={cartButtonLink} className={`btn btn-secondary ${styles.cartButton}`}>{cartButtonText}</a>
            </div>
        </div>
    </div>
);
