import { Link, useNavigate } from 'react-router-dom';
import { useState } from "react";
import styles from "./Login.module.css";
import { isEmailValid } from "../../helpers/Email.helper";
import ValidationError from "../../components/validation-error/validationError";

export function LoginPage() {
  const [form, setForm] = useState({
    email: {
      hasChanged: false,
      value: "",
    },
    password: {
      hasChanged: false,
      value: "",
    },
  });

  const navigate = useNavigate();

  const handleLogin = () => {
    navigate('/home');
  };

  return (
    <div className={styles.container}>
      <main className={styles.centralize}>

        <section className={styles.section}>
          <div className={styles.text}>
            <h3>BEM-VINDO!</h3>
            <p>ENTRE NA SUA CONTA</p>
          </div>
        </section>

        <section className={styles.section}>
          <form className={styles.form}>
            <section className={styles.inputEmail}>
              <span className={`bi bi-person-fill ${styles.customIcons}`}></span>
              <input type="email" placeholder="Email" value={form.email.value}
                onChange={(event) => setForm({
                  ...form, email: {
                    hasChanged: true, value: event.target.value,
                  }
                })}
                data-testid="email" />
            </section>

            <ValidationError
              hasChanged={form.email.hasChanged}
              errorMessage="Email é obrigatório"
              testId="email-required"
              type="required"
              value={form.email.value} />

            <ValidationError
              hasChanged={form.email.hasChanged}
              errorMessage="Email é inválido"
              testId="email-invalid"
              type="email"
              value={form.email.value} />

            <section className={styles.inputPassword}>
              <span className={`bi bi-key-fill ${styles.customIcon}`}></span>
              <input type="password" placeholder="Senha" value={form.password.value}
                onChange={(event) => setForm({
                  ...form, password: {
                    hasChanged: true, value: event.target.value,
                  }
                })}
                data-testid="password" />
            </section>

            <ValidationError
              hasChanged={form.password.hasChanged}
              errorMessage="Senha é obrigatória"
              testId="password-required"
              type="required"
              value={form.password.value} />

          </form>
        </section>

        <section className={styles.section}>
          <button type="button" className={styles.forget} data-testid="recover-password-button"
            disabled={!isEmailValid(form.email.value)}>
            Esqueceu a senha?
          </button>

          <Link to="/" ><button className={styles.enter} >ENTRAR</button></Link>

        </section>
      </main>

      <div className={styles.cadastro}>
        <p>ou</p>
        <button>CADASTRE-SE</button>
      </div>
    </div>
  );
}
