import styles from './CSS/Slides.module.css';
import image1 from '../../assets/images/gojo-vs-sukuna-manga-jjk.jpg';

export function CarouselSlides() {
    return (
        <div>
            <section className={styles.sectionSpacing}>
                <div id="carouselExampleIndicators" className={`carousel slide ${styles.carouselSlides}`}>
                    <div className={`carousel-indicators ${styles.indicators}`}>
                        <button
                            type="button"
                            data-bs-target="#carouselExampleIndicators"
                            data-bs-slide-to="0"
                            className="active"
                            aria-current="true"
                            aria-label="Slide 1"
                        ></button>
                        <button
                            type="button"
                            data-bs-target="#carouselExampleIndicators"
                            data-bs-slide-to="1"
                            aria-label="Slide 2"
                        ></button>
                        <button
                            type="button"
                            data-bs-target="#carouselExampleIndicators"
                            data-bs-slide-to="2"
                            aria-label="Slide 3"
                        ></button>
                    </div>

                    <div className="carousel-inner">
                        <div className="carousel-item active">
                            <img
                                src={image1}
                                className="d-block w-100"
                                alt="Gojo vs Sukuna"
                                width={1920}
                                height={300}
                                style={{ objectFit: "cover", objectPosition: "center top" }}
                            />
                        </div>
                        <div className="carousel-item">
                            <img
                                src={"https://picsum.photos/seed/picsum/1920/300"}
                                className="d-block w-100"
                                alt="Descrição da imagem 2"
                            />
                        </div>
                        <div className="carousel-item">
                            <img
                                src={"https://picsum.photos/seed/picsum/1920/300"}
                                className="d-block w-100"
                                alt="Descrição da imagem 3"
                            />
                        </div>
                    </div>

                    <button
                        className={`carousel-control-prev ${styles.carouselButton}`}
                        type="button"
                        data-bs-target="#carouselExampleIndicators"
                        data-bs-slide="prev"
                    >
                        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Previous</span>
                    </button>

                    <button
                        className={`carousel-control-next ${styles.carouselButton}`}
                        type="button"
                        data-bs-target="#carouselExampleIndicators"
                        data-bs-slide="next"
                    >
                        <span className="carousel-control-next-icon" aria-hidden="true"></span>
                        <span className="visually-hidden">Next</span>
                    </button>
                </div>
            </section>
        </div>
    );
}
