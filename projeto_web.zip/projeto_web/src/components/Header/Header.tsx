import React from 'react';
import styles from './Header.module.css';

export const Header: React.FC = () => {
  return (
    <header className={styles.header}>
      <nav className="navbar">
        <div className="container-fluid">
          <a className="navbar-brand" href='/'>
            <img src="" alt="Logo" width="30" height="30" className="d-inline-block align-text-top" />        
          </a>
          
          <form className="d-flex" role="search">
            <div className={`${styles.inputGroup} input-group`}>
              <input className={`${styles.formControl} form-control`} type="search" placeholder="" aria-label="Search" />
              <button className={styles.btn} type="submit">
                <i className="bi bi-search"></i> {/* Ícone de lupa */}
              </button>
            </div>
          </form>
        </div>
      </nav>
    </header>
  );
}

