export interface CardData {
    title: string;
    text: string;
    imageSrc: string;
    price: number;
}