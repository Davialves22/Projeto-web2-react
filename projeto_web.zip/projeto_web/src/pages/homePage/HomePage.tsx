import styles from "./CSS/Home.module.css";
import { OfertaDiaria } from './../../components/carroussel/OfertaDiaria'
import { PromocaoCards } from './../../components/carroussel/PromocaoCards';
import { CarouselSlides } from './../../components/carroussel/carrousseSlides'

export function HomePage() {
  return (
    <>
      <h1>HomePage</h1>
      <CarouselSlides />

      <section className="container">
        <div className={styles.container}>
          <OfertaDiaria />

          <section className={styles.Itens}>
            <ul>
              <li>item 1</li>
              <li>item 2</li>
              <li>item 3</li>
              <li>item 4</li>
              <li>item 5</li>
            </ul>

          </section>

          <PromocaoCards />
        </div>
      </section>
    </>
  );
}
