import React from "react";
function Register(){
    return(
<h1>Register Page</h1>
    )
}
export default Register;